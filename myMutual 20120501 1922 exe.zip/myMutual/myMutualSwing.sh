#!/bin/bash

echo --------------------------------------------------------------------------
echo -- Ejecutando myMutualSwing...
echo --------------------------------------------------------------------------

# Setear el Path al JRE o al JDK de Java

export dir_java_pc=/usr/lib/jvm
export dir_java_app=../..
export jre=jre/bin
export jdk=jdk/bin
export prg=java
export jar=myMutualSwing.jar

# Si Existe el JRE que trae la Aplicación, entonces Utilizarlo
if [ -d ${dir_java_app}/$jre ] ; then
	export PATH=${dir_java_app}/$jre:$PATH
# Sino, Si Existe el JRE en el Directorio por Defecto, entonces Utilizarlo
elif [ -d ${dir_java_pc}/$jre ] ; then
	export PATH=${dir_java_pc}/$jre:$PATH
# Sino, Si Existe el JDK que trae la Aplicación, entonces Utilizarlo
elif [ -d ${dir_java_app}/$jdk ] ; then
	export PATH=${dir_java_app}/$jdk:$PATH
# Sino, Si Existe el JDK en el Directorio por Defecto, entonces Utilizarlo
elif  [ -d ${dir_java_pc}/$jdk ] ; then
	export PATH=${dir_java_pc}/$jdk:$PATH
# Sino, Utilizar el JRE o JDK que está Seteado en la Variable de Entorno
fi

# Ejecutar
$prg -jar $jar